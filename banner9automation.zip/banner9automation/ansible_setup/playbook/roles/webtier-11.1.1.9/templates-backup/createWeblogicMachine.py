###############################################################################
#
#    This wlst script shows you how to create a WebLogic Machine into a domain
#    Copyright (c) 2015 - 2017 by Tomoiu Paul Catalin, All Rights Reserved.
#
###############################################################################
 
connect('weblogic','wllaureate1', 't3://localhost:7001')
print ''
print '======================================================'
print 'The script has been connected to the Admin Server'
print '======================================================'
print ''
 
edit()
startEdit()
 
# Machine-1 = the new WebLogic Machine
cmo.createUnixMachine('localhost')
 
cd('/Machines/localhost/NodeManager/localhost')
cmo.setListenAddress('localhost')
 
 
activate()
 
# This is the end of the script
