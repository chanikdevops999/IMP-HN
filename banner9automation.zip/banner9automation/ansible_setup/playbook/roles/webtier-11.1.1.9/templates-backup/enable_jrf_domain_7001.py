#!/usr/bin/python
import os, sys
readDomain('/u01/app/oracle/Middleware/user_projects/domains/base_domain')
addTemplate('/u01/app/oracle/Middleware/oracle_common/common/templates/applications/jrf_template_11.1.1.jar')
addTemplate('/u01/app/oracle/Middleware/oracle_common/common/templates/applications/oracle.em_11_1_1_0_0_template.jar')
updateDomain()
closeDomain()
exit()
