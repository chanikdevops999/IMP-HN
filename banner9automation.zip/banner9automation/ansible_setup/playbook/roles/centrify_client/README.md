Centrify Client
=========

Installs the centirfy client software and joins the server to the domain

Role Variables
--------------

+ vars:
    + join - If true the server is joined to the domain
      management server
        + default: true
    + cetrify_ou - OU in AD to join to
        + default: "OU=Servers,OU=Centrify"
    + domain - Domain to join
        + default: loe.corp
    + zone - Centrify zone to join
        + default: global

Example Playbook
----------------

    - hosts: servers
      roles:
         - { role: centrify-join, join: false }

