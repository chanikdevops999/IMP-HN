#!/bin/bash

# Author: Sharad Kumar Chhetri
# Date: 20Jan2019
# Description: Copy DB backup to s3 bucket.

_DUMP_OSPATH=/dump/backup/rman/
_DATE=$(date +%d%m%Y)
_HOSTNAME=$(hostname)
_BUCKET_NAME=waldenprod-dbbackup

_DBLIST=$(ls $_DUMP_OSPATH)


for _DBNAME in $_DBLIST;
do
# create directory in s3 bucket
aws s3api put-object --bucket "$_BUCKET_NAME" --key "$_HOSTNAME/$_DATE/rman/$_DBNAME/"
ls -Al --time-style=+%D $_DUMP_OSPATH/$_DBNAME|grep $(date +%D)|awk '{print $7}' > /tmp/$_DBNAME

for i in `cat /tmp/$_DBNAME`
do
# Copy to s3 bucket
aws s3 cp "$_DUMP_OSPATH/$_DBNAME/$i" s3://$_BUCKET_NAME/$_HOSTNAME/$_DATE/rman/$_DBNAME/
done
done
