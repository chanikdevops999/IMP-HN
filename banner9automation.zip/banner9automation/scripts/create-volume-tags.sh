#!/bin/bash
#
# Description: Create and update volume tags
# Version : 1.0
# Author: Sharad <sharad.chhetri@harman.com >
# Command Help: sh create-volume-tags.sh -r <aws-region-code> -s <cloudformation-stack-name> -e <Environment Name> -u <University Name> -a <Account if>
# example: sh create-volume-tags.sh -r us-east-1 -s WaldenDevEnv -e dev -u walden -a 13
#################


# Cloudprovider code for aws is 'a'
_cloudprovider=a
_region=""
_StackName=""
_Env=""
_Univ=""
_AccntId=""
_aws_profile=""
#_profile=BannerNonProdAccount


while getopts "r:s:e:u:a:p:" opt
do
case $opt in
r ) _region=$OPTARG;;
s ) _StackName=$OPTARG;;
e ) _Env=$OPTARG;;
u ) _Univ=$OPTARG;;
a ) _AccntId=$OPTARG;;
p ) _aws_profile=$OPTARG;;
esac
done

if [ ! "$_region" ]
then
printf "ERROR - Give AWS Region Code eg. us-east-1 -r\n"
exit 3
fi
if [ ! "$_StackName" ]
then
printf "ERROR - Give CloudFormation Stack Name -s\n"
exit 3
fi
if [ ! "$_Env" ]
then
printf "ERROR - Give Environment Name eg. dev|qa|sandbox|prod -e\n"
exit 3
fi
if [ ! "$_Univ" ]
then
printf "ERROR - Give University Name eg. walden -u\n"
exit 3
fi
if [ ! "$_AccntId" ]
then
printf "ERROR - Give Account id eg. 13 -a\n"
exit 3
fi
if [ ! "$_aws_profile" ]
then
printf "ERROR - Give AWS Profile eg. nonprod  -p\n"
exit 3
fi

####
if [ "$_region" == 'us-east-1' ]
then
	_regioncode=ue
elif [ "$_region" == 'us-west-2' ]
then
	_regioncode=uw
else
	echo "Only these Region values are allowed - 'us-east-1' and 'us-west-2' "
	echo 0
fi

## AWS profile
####
if [ "$_aws_profile" == 'prod' ]
then
	_profile=BannerProdAccount
elif [ "$_aws_profile" == 'nonprod' ]
then
	_profile=BannerNonProdAccount
else
	echo "Only these aws profiles values are allowed - 'BannerNonProdAccount' and 'BannerProdAccount' "
	echo 0
fi

### Environment Code
if [ "$_Env" == 'dev' ]
then
	_envcode=d
	_env_class=Dev
elif [ "$_Env" == 'qa' ]
then
	_envcode=q
	_env_class=QA
elif [ "$_Env" == 'sandbox' ]
then
	_envcode=x
	_env_class=Sandbox
elif [ "$_Env" == 'test' ]
then
	_envcode=t
	_env_class=Test
elif [ "$_Env" == 'prod' ]
then
	_envcode=p
	_env_class=Production
else
	echo "Only these Environment values are allowed - 'dev','sandbox','qa','prod','test'"
	exit 1
fi
# Get Instance Ids of ec2 launched in Cloudformation Stack

_instance_id_list=$(aws --region $_region --profile $_profile ec2 describe-instances --filters "Name=tag:aws:cloudformation:stack-name,Values=$_StackName" --query 'Reservations[*].Instances[*].[InstanceId]' --output text)


for i in $_instance_id_list;
do
	_volume_id_list=$(aws --region $_region --profile $_profile ec2 describe-volumes --filters "Name=attachment.instance-id,Values="$i"" --query Volumes[*].Attachments[*].[VolumeId] --output text)
	_role=$(aws --region $_region --profile $_profile ec2 describe-instances --instance-id  $i --query 'Reservations[*].Instances[*].[Tags[?Key==`Role`]|[0].Value]' --output text)
	_application=$(aws --region $_region --profile $_profile ec2 describe-instances --instance-id  $i --query 'Reservations[*].Instances[*].[Tags[?Key==`Application`]|[0].Value]' --output text)
	_os=$(aws --region $_region --profile $_profile ec2 describe-instances --instance-id  $i --query 'Reservations[*].Instances[*].[Tags[?Key==`OperatingSystem`]|[0].Value]' --output text)
	_tier=$(aws --region $_region --profile $_profile ec2 describe-instances --instance-id  $i --query 'Reservations[*].Instances[*].[Tags[?Key==`Tier`]|[0].Value]' --output text)

	for k in $_volume_id_list
	do
		_created_date=$(aws --region $_region --profile $_profile ec2 describe-volumes --filters "Name=volume-id,Values=$k" --query Volumes[*].[CreateTime] --output text)
		_device=$(aws --region $_region --profile $_profile ec2 describe-volumes --filters "Name=volume-id,Values=$k" --query Volumes[*].Attachments[*].[Device] --output text | sed 's/\/dev\///g')

		_created_date_convert=$( date -d "$_created_date" +"%d-%b-%Y" )

		# Availability Zone #
		_az=$(aws --region $_region --profile $_profile ec2 describe-volumes --filters "Name=volume-id,Values=$k" --query Volumes[*].[AvailabilityZone] --output text)

		if [ "$_az" == 'us-east-1a' ] || [ "$_az" == 'us-west-1a' ]
		then
			_azcode=aza
			_node=001
		elif [ "$_az" == 'us-east-1b' ] || [ "$_az" == 'us-west-1b' ]
		then
			_azcode=azb
			_node=002
		else
			echo "Only supporting now AZ value 'us-east-1a' and 'us-east-1b' "
			exit 2
		fi


		# echo "#####################################"
		 #echo "InstanceId: $i"
		 #echo "VolumeId: $k"
		# echo "Device: $_device"
		# echo "CreatedDate: $_created_date_convert"
		# echo "StackName: $_StackName"
		# echo "Environment: $_Env"

		## Create tags and attach to Volume ###
		# aws --region $_region --profile $_profile ec2 create-tags --resources $k --tags Key=InstanceId,Value=$i
		# aws --region $_region --profile $_profile ec2 create-tags --resources $k --tags Key=VolumeId,Value=$k
		# aws --region $_region --profile $_profile ec2 create-tags --resources $k --tags Key=Device,Value=$_device
		# aws --region $_region --profile $_profile ec2 create-tags --resources $k --tags Key=CreatedDate,Value=$_created_date_convert

		# aws --region $_region --profile $_profile ec2 create-tags --resources $k --tags Key=Stack,Value=$_StackName
		# aws --region $_region --profile $_profile ec2 create-tags --resources $k --tags Key=Environment,Value=$_Env
		# aws --region $_region --profile $_profile ec2 create-tags --resources $k --tags Key=University,Value=$_Univ
		# aws --region $_region --profile $_profile ec2 create-tags --resources $k --tags Key=AccountId,Value=$_AccntId

		# aws --region $_region --profile $_profile ec2 create-tags --resources $k --tags Key=Name,Value="$_cloudprovider-$_AccntId"

		_name="$_cloudprovider$_AccntId$_regioncode$_envcode-ebs-$_azcode-$_role-$_node-$_device"
		echo "$i $k $_name $_os $_tier"

	done

done
