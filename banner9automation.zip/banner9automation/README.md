# TABLE OF CONTENTS
1. [About Git Repo](#about-git-repo)
    - [Flow Diagram](#flow-diagram)
    - [Packer](#packer)
    - [Ansible](#ansible)
    - [Cloudformation](#cloudformation)
    - [Jenkins](#jenkins)
2. [Setup Jenkins-Ansible Server](#setup-jenkins-ansible-server)
3. [Configure 'One Click Automation' Setup In Jenkins](#configure-one-click-automation-setup-in-jenkins) :star:
    - [Create Jenkins Job 1 for 'One Click Automation'](#create-jenkins-job-1-for-one-click-automation)
    - [Create Jenkins Job 2 for 'One Click Automation'](#create-jenkins-job-2-for-one-click-automation)
    - [Run Jenkins Pipeline View](#run-jenkins-pipeline-view)
4. [Backend Technologies](#backend-technologies)
    - [Ansible](#ansible-1)
      - [First Ansible Playbook Execution](#first-ansible-playbook-execution)
      - [Ansible 'packer' role](#ansible-packer-role)
      - [Ansible 'aws' role](#ansible-aws-role)
      - [Ansible 'dynamic' role](#ansible-dynamic-role)
    - [Cloudformation](#cloudformation-1)
    - [Packer](#packer-1)


# About Git Repo
This is Ansible,Packer and Cloudformation Setup repo.

<b>Note:</b> Copy the EC2 Keypairs in Jenkins Server in relevant path. Check the Inventory file variables for placing key in correct path.

## Flow Diagram

![Alt text](docs-img/Ansible-BannerAutomation.png?raw=true "Ansible Banner Automation")

## Packer
Packer is using "Ansible Remote" provisioner.
In ansible master setup, we are using 'tag: packer' in some tasks. The 'tag: packer' is directly invoked from packer template file, hence contact Ansible Administrator for any questions.

## Ansible
Ansible Master server is the main controller which perform mainly 3 roles
- Create Packer AMI
- Trigger AWS Cloudformation Template
- Centralized Configuration Tool for Servers/Application

## Cloudformation

- Cloudformation template is written in json
- After creating/updating the Cloudformation template , copy to s3 bucket directory.
  Then in Ansible setup update the ansible global variable file.

## Jenkins
Jenkins is used here for executing the Ansible 'Master' code.
 - From Jenkins Job the code will be pulled from Github.
 - Later Ansible playbook will be executed from Jenkins job.

![Alt text](docs-img/ascii-automation-flow.png?raw=true "Jenkins")

# Setup Jenkins-Ansible Server

The installation of Jenkins and ansible master should be done in 'single server'

- Install JDK
  * Download latest JDK https://www.oracle.com/technetwork/java/javase/downloads/index.html
  * By using rpm command install the JDK package.
    <pre>sudo rpm -ivh jdk-version-???.rpm</pre>
  * Set Java environment
- Install Jenkins
  * Download latest LTS Jenkins Generic Java Package (.war) https://jenkins.io/download/ and copy it to /opt
    <pre>
    sudo mkdir -p /opt/jenkins
    cd /opt/jenkins
    sudo wget http://mirrors.jenkins.io/war-stable/latest/jenkins.war
    </pre>
  * Install Jenkins
    <pre>
    sudo su
    cd /opt/jenkins
    nohup java -jar jenkins.war &
    </pre>
    In a few seconds, the jenkins process will be running and by defaulr listening to port 8080.
    Open the web browser and type http://jenkins-server-ip-address:8080 . It will open the Jenkins first time installation page, follow the instructions to install the Jenkins.

    **Reference:** https://jenkins.io/doc/book/installing/#war-file

- Install git client
  <pre>
  sudo yum install git
  </pre>
- Install Ansible by using pip.
  <pre>
  #### install pip
  sudo yum install python-pip

  #### install Ansible
  sudo su - Jenkins
  pip install ansible
  pip install boto2
  pip install boto3
  </pre>
  **Dependencies for Ansible modules** : Python modules - boto2 and boto3

- Install Packer
  * Download packer https://releases.hashicorp.com/packer/1.3.2/packer_1.3.2_linux_amd64.zip
  * Unzip the package
  * Copy the unzipped 'packer' binary file to /usr/local/bin
  * Give the executable permission to packer binary file.
    <pre>
    sudo chmod +x /usr/local/bin/packer
    </pre>

# Configure 'One Click Automation' Setup In Jenkins

The 'One Click Automation' setup is logically divided into two phases.
 * **Job 1** : It comprises of AWS related tasks which includes
        - Building Packer AMI
        - Executing AWS Cloudformation
 * **Job 2** : It comprises of Ansible task which will install,setup and configure the servers/applications. Like installing prereqs,updating server configuration files, application installation/setup etc. In simple words - Act as a Centralized Configuration by using Ansible.

## Create Jenkins Job 1 for 'One Click Automation'

(i) General:
  In this section, give details in 'Description Box'
![Alt text](docs-img/jenkins-job1-a.png?raw=true "Jenkins Job 1")

(ii) Source Code Management:
  In this section, configure the GIT information.

![Alt text](docs-img/jenkins-job1-b.png?raw=true "Jenkins Job 1")

(iii) Build Triggers:
  In this section, we have not set anything.

![Alt text](docs-img/jenkins-job1-c.png?raw=true "Jenkins Job 1")

(iv) Build Environment:
  In this section, we have not set anything

![Alt text](docs-img/jenkins-job1-d.png?raw=true "Jenkins Job 1")

(v) Build:
 In this section, write command in "Execute Shell"

<pre>
ansible-playbook -vvv  -i ansible_setup/inventory/walden-qa  ansible_setup/playbook/prod-packer-cft.yml --extra-vars "repo_path_system=$WORKSPACE" --extra-vars "jenkins_build_number=$BUILD_NUMBER" --extra-vars "@./ansible_setup/inventory/group_vars/walden-qa.yml" --extra-vars "jenkins_phase=aws-setup"
</pre>

**-i ansible_setup/inventory/walden-qa**
With ''-i' parameter give inventory file path.

**--extra-vars "@./ansible_setup/inventory/group_vars/walden-qa.yml"**
Here, with '--extra-vars' give variable file path.

**--extra-vars "jenkins_phase=all"**
In First Jenkins Job, give this variable value

![Alt text](docs-img/jenkins-job1-e.png?raw=true "Jenkins Job 1")

(vi) Post-build Actions:
    In this section, we have not set anything

Click 'Apply' button at the end.

## Create Jenkins Job 2 for 'One Click Automation'

The Job 2 settings is almost same as above like Job 1. To see the difference, you can directly move to 'Build' section.

(i) General:
  In this section, give details in 'Description Box'
![Alt text](docs-img/jenkins-job2-a.png?raw=true "Jenkins Job 2")

(ii) Source Code Management:
  In this section, configure the GIT information.

![Alt text](docs-img/jenkins-job2-b.png?raw=true "Jenkins Job 2")

(iii) Build Triggers:
  In this section, we have not set anything.

![Alt text](docs-img/jenkins-job2-c.png?raw=true "Jenkins Job 2")

(iv) Build Environment:
  In this section, we have not set anything

![Alt text](docs-img/jenkins-job2-d.png?raw=true "Jenkins Job 2")

(v) Build:
 In this section, write command in "Execute Shell"

 <pre>
 ansible-playbook -vvv -i ansible_setup/inventory/walden-qa  ansible_setup/playbook/prod-packer-cft.yml --extra-vars "repo_path_system=$WORKSPACE" --extra-vars "jenkins_build_number=$BUILD_NUMBER" --extra-vars "@./ansible_setup/inventory/group_vars/walden-qa.yml" --extra-vars "jenkins_phase=all"
 </pre>

**-i ansible_setup/inventory/walden-qa**
With ''-i' parameter give inventory file path.

**--extra-vars "@./ansible_setup/inventory/group_vars/walden-qa.yml"**
Here, with '--extra-vars' give variable file path.

**--extra-vars "jenkins_phase=all"**
In Second Jenkins Job, give this variable value

![Alt text](docs-img/jenkins-job2-e.png?raw=true "Jenkins Job 2")

(vi) Post-build Actions:
    In this section, we have not set anything

Click 'Apply' button at the end.

## Create Jenkins Pipeline View

Now, we will create a "Jenkins Pipeline View" in which we will combine both above created Jenkins Jobs i.e Job1 and Job2 .

**How to create Jenkins Pipeline View**
Go to Jenkins console main page. In Jenkins 'Pipeline View' plugin should be installed. It will enable to create 'Pipeline View' from Jenkins Console.
As per given below screenshot, to create new 'Pipeline View', click on " + " sign.

![Alt text](docs-img/create-pipeline-view.png?raw=true "Jenkins Pipeline View")

**Configure the Jenkins Pipeline View**
Set the configuration as given below. Here in end of this screenshot, we have joined both Jenkins Jobs which we have created in earlier steps.

![Alt text](docs-img/jenkins-pipeline-view-1.png?raw=true "Jenkins Pipeline View")

## Run Jenkins Pipeline View

After creating the 'Pipeline View', you will find one 'Build Now' button. You have to only click this button.
It will execute the First Job and later Second if First Job is successfully executed.

In given below screenshot, Yellow highlighted is 'Build Now'

![Alt text](docs-img/run-pipeline-view.png?raw=true "Jenkins Pipeline Run")

# Backend Technologies
This section includes about the technologies which are used for running the complete stack.
- Ansible
- Cloudformation
- Packer

![Alt text](docs-img/gitrepo.png?raw=true "Backend Technologies")

## Ansible
Ansible is the Master of this stack. From Ansible we are executing all other automation tool.
The flow of Ansible execution is described in this document section called [Flow Diagram](#flow-diagram).

In repo directory called 'ansible_setup' contains all the Ansible code.

### First Ansible Playbook Execution

The main playbook file to run the 'One Click Automation' is **{Environment-Name}-packer-cft.yml**
Replace the **Environment-Name** value with environment code. This is the 'Master Automation playbook' which will do end to end infra setup.

The 'Master Automation playbook' basically call the 3 Ansible Roles in given below serial order:
- packer (It will build the AWS AMI)
- aws (It will create/manage the AWS infrastructure)
- dynamic (It will help to Centrally Managed the server/application configurations)

Given below is example from Production 'Master Automation Playbook'.
<pre>
---
# aws packer ansible cloudformation #
- name: Walden Production Packer Cloudformation Setup
  hosts: 127.0.0.1
  connection: local
  gather_facts: False
  roles:
    - { role: packer, when: jenkins_phase == 'aws-setup' or jenkins_phase == 'all' }
    - { role: aws, when: jenkins_phase == 'aws-setup' or jenkins_phase == 'all' }
    - { role: dynamic, when: jenkins_phase == 'all' }
</pre>

In above code, jenkins_phase == 'aws-setup' and jenkins_phase == 'all' are conditions created specifically to run the Jenkins [Job 1](#create-jenkins-job-1-for-one-click-automation) and [Job 2](#create-jenkins-job-2-for-one-click-automation) .


## Ansible 'packer' role
Packer is for creating AWS AMI. With the help of Ansible the Packer AMI are getting created.
In Ansible, the role 'packer' is dedicated for all packer related tasks.

In git repo, the 'packer' directory contains all the packer build files.

Here the packer is using the ['Ansible Remote'](https://www.packer.io/docs/provisioners/ansible.html) provisioner to run the ansible script to install/configure packages in EC2 AMI.

**Ansible Logical Execution Flow Diagram:**
![Alt text](docs-img/ansible-flow.png?raw=true "Ansible Internal Flow")

In given below screenshot, the Packer build file path is depicted.

![Alt text](docs-img/packer-build-dir.png?raw=true "Packer Build Files Location")

## Ansible 'aws' role

The ansible 'aws' role plays vital role in building AWS infrastructure.

**In following serial order these tasks will be executed:**
- Get the Packer AMI ID created from 'packer' role.
- Create ENI (Before executing the cloudformation template)
- Execute AWS Cloudformation template from ansible. Create or Update AWS Cloudformation Stack.
- Get the facts of resources created by Cloudformation.
- Create and Attach EBS Volumes to required servers.

## Ansible 'dynamic' role

The ansible 'dynamic' role helps to install packages and configure the server/application. In other words, you can consider it as 'Centralized Configuration' role for servers/applications.

**In following serial order these tasks will be executed:**
- Create a ansible inventory file with respect to 'Environment'. It has inventory of all the EC2 IP address in the 'Environment| (prod,qa,staging,dev etc.)'
- The playbook called 'dynamic.yml' . It will execute the roles which are written in this file.

## Cloudformation

Cloudformation template is written in json format. In git repo, the directory called 'cloudformation' contains all the CFT file.

The updated cloudformation template should be saved in S3 bucket before execution of 'Ansible Master Playbook'.

## Packer
Packer is used for creating AMI and integrated with Ansible. We have already described about Ansible packer execution in above section.
