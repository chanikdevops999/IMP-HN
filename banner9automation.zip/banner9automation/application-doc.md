# TABLE OF CONTENTS
1. [Introduction](#introduction)
2. [EIS](#ethos)
   - [EIS Flow Diagram](#eis-flow-diagram)
   - [Update the EIS variables](#update-the-eis-variables)
   - [Steps to run the EIS playbook](#steps-to-run-the-eis-playbook)
3. [Workflow](#workflow)
   - [Workflow Flow Diagram](#workflow-flow-diagram)
   - [Update the Workflow variables](#update-the-Workflow-variables)
   - [Steps to run the Workflow playbook](#steps-to-run-the-workflow-playbook)
4. [BEIS](#BEIS)
   - [BEIS Flow Diagram](#beis-flow-diagram)
   - [Update the BEIS variables](#update-the-beis-variables)
   - [Steps to run the BEIS playbook](#steps-to-run-the-beis-playbook)

# Introduction
 This repository contains Ansible roles and playbooks for Installing tomcat and deploying the Applications.

# EIS Flow Diagram
<p align="center"><img src="docs-img/eis-BannerAutomation.png" width="400" height="350">


## Update the EIS variables
	- Open the varibles file based on the environment which you going to setup
	  Example:if you are running for SANDBOX open the walden-sandbox.yml.
		   Location - ansible_setup/inventory/group_vars/
    - Go to "eis" section and update the eis server details,database details and service url.

          eis_domain_name:
          s3_client_truststore_download_url: https://s3.amazonaws.com/lobannerawsdev.codetemplates/Ethos/Certs/client-truststore.jks
          truststore_certificate_name: eis_waldenu_edu.jks
          s3_truststore_download_url: https://s3.amazonaws.com/lobannerawsdev.codetemplates/Ethos/Certs/eis_waldenu_edu.jks
          keystore_password:
          keystore_private_key_alias:
          keystore_private_key_password:
          database_type: oracle
          database_host:
          database_port:
          database_name:
          database_username:  
          database_password:
          idp_samlsso_id:


## Steps to run the EIS playbook
	- Verify the Varibles in group_vars location.
	- Then change the directory to ansible_setup.
	- Run the below command.

	   ansible-playbook -i "Path of the inventory file" playbook/eis.yml --extra-vars "@./inventory/group_vars/variable file"

	   Example:
	   ansible-playbook -i ~/WaldenSandboxEnv.ini playbook/eis.yml --extra-vars "@./inventory/group_vars/walden-sandbox.yml"


# Workflow Flow Diagram
<p align="center"><img src="docs-img/workflow-BannerAutomation.png" width="400" height="350">


## Update the Workflow variables
	- Open the varibles file based on the environment which you going to setup
	  Example:if you are running for SANDBOX open the walden-sandbox.yml.
		   Location - ansible_setup/inventory/group_vars/
    - Go to "tomcat" section and update the tomcat server details,database details and service url.

          db_connection_url: jdbc:oracle:thin:@<server-name>:<port>:<instance-name>
          db_password:
          banner_db_connection_url: jdbc:oracle:thin:@<server-name>:<port>:<instance-name>
          banner_db_username: workflow
          banner_db_user:
          banner_db_password:
          workflow_banneruser: wfbanner
          workflow_dbuser: workflow
          workflow_password:


## Steps to run the Workflow playbook
	- Verify the Varibles in group_vars location.
	- Then change the directory to ansible_setup.
	- Run the below command.

	   ansible-playbook -i "Path of the inventory file" playbook/workflowtomcat.yml --extra-vars "@./inventory/group_vars/variable file"

	   Example:
	   ansible-playbook -i ~/WaldenSandboxEnv.ini playbook/workflowtomcat.yml --extra-vars "@./inventory/group_vars/walden-sandbox.yml"


# BEIS Flow Diagram
<p align="center"><img src="docs-img/beis-BannerAutomation.png" width="400" height="350">


## Update the BEIS variables
	- Open the varibles file based on the environment which you going to setup
	  Example:if you are running for SANDBOX open the walden-sandbox.yml.
		   Location - ansible_setup/inventory/group_vars/
    - Go to "beis" section and update the tomcat server details,database details and service url.

        integmgr_user: INTEGMGR
        integmgr_password:
        ssomgr_user: SSOMGR
        ssomgr_password:
        ssomgr_jdbc_bannerDataSource_url: jdbc:oracle:thin:@<host-name>:<bort>/<instance-name>


## Steps to run the beis playbook
	- Verify the Varibles in group_vars location.
	- Then change the directory to ansible_setup.
	- Run the below command.

	   ansible-playbook -i "Path of the inventory file" playbook/beis.yml --extra-vars "@./inventory/group_vars/variable file"

	   Example:
	   ansible-playbook -i ~/WaldenSandboxEnv.ini playbook/beis.yml --extra-vars "@./inventory/group_vars/walden-sandbox.yml"
