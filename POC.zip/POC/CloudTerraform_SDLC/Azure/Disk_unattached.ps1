﻿


$alldisk = Get-AzDisk -ResourceGroupName dev_rg


foreach ( $VMdisk in $alldisk )
{

$disk_name =  $VMdisk.Name

$disk_state = $VMdisk.DiskState 

$disktag = $VMdisk.Tags



Write-Output $disk_state

Write-Output $disktag

    if ($disk_state -ne  "attached" )
    {
    Write-Output "$disk_name is not attached to any of the VM"
    }
   
    if ($disktag.Values -ne  " " )
    {
    Write-Output "$disk_name do have tag associated"
    }
    else
    {
    Write-Output "$disk_name dont have any tag associated"
    }
    

}




