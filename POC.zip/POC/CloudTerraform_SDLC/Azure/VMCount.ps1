﻿

$VMfile = "./VMfile.txt"

$vmdetails = Get-AzVM -ResourceGroupName "dev_rg"  

$expcount = 4

$curcount = $vmdetails.Count 


if ( $curcount -gt $expcount )
{
    write-output "New VM is added in this resource group" 

}

if ( $curcount -lt $expcount )
{
    write-output " VM is removed from this resource group" 

}

