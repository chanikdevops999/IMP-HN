﻿


$alldisk = Get-AzDisk -ResourceGroupName dev_rg


foreach ( $VMdisk in $alldisk )
{

$disk_name =  $VMdisk.Name

$disk_size = $VMdisk.disksizegb

$disk_state = $VMdisk.DiskState 



Write-Output "$disk_name $disk_size $disk_state "

    

}




