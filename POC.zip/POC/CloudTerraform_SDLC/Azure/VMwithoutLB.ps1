﻿


$nicinfo = Get-AzNetworkInterface -ResourceGroupName test_rg


$nic_name = $nicinfo.Name

Write-Output $nic_name


foreach ( $nic in $nic_name )
{


 $lb = Get-AzLoadBalancer -ResourceGroupName test_rg

 $checknic = $lb.BackendAddressPools | findstr -i $nic

 #Write-Output $checknic
 
    if (  $checknic -eq $null )
    {
    Write-Output $nic 
    
    $vm_alone =Get-AzNetworkInterface -Name $nic  | Select @{Name="VMName";Expression = {$_.VirtualMachine.Id.tostring().substring($_.VirtualMachine.Id.tostring().lastindexof('/')+1)}}
   
    Write-Output "$vm_alone is not attached to any LB"

    }

 
}
