﻿



#Connect-AzAccount 

$VMdetails = Get-AzVM -ResourceGroupName "dev_rg" 


foreach ( $VMName in $VMdetails )
{

$vm_name =  $VMName.Name

$tagstate = $VMName.tags 

    if ($tagstate.Values -ne  " " )
    {
    Write-Output "$vm_name do have tag associated"
    }
    else
    {
    Write-Output "$vm_name dont have any tag associated"
    }
    

}



