﻿

$rg_name = "test_rg"



$newvmdata = Get-AzVM -ResourceGroupName $rg_name -Status 

#Write-Output $vmdetails

foreach ( $vmdata in $newvmdata ) 

{

$VM = Get-AzVM -Name $vmdata


$Profile =$VM.NetworkProfile.NetworkInterfaces.Id.Split("/") | Select -Last 1

$IPConfig = Get-AzNetworkInterface -Name $Profile

$IPAddress = $IPConfig.IpConfigurations.PrivateIpAddress



Write-Output " VM name is $VM, Private IP address is  $IPAddress"

}
