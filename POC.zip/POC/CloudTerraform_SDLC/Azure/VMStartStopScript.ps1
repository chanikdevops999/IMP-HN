


#Connect-AzAccount 

$VMfile = "./VMfile.txt"


foreach ( $vmtoconsider in get-content "$VMfile" )
{

Write-Output "$vmtoconsider is stopping now"

Stop-AzVM -ResourceGroupName "dev_rg" -Name "$vmtoconsider" -Force

sleep 2 

$state = Get-AzVM -ResourceGroupName "dev_rg" -Name "$vmtoconsider" -Status

sleep 2 

    if ($state.Statuses[1].DisplayStatus -eq "VM deallocated")
    {
    Write-Output "$vmtoconsider is stopped successfully"
    }
    else
    {
    Write-Output "$vmtoconsider is failed to stop"
    }

}




foreach ( $vmtoconsider in get-content "$VMfile" )
{

Write-Output "$vmtoconsider is staring now"

Start-AzVM -ResourceGroupName "dev_rg" -Name "$vmtoconsider" 

sleep 2 

$state = Get-AzVM -ResourceGroupName "dev_rg" -Name "$vmtoconsider" -Status

sleep 2 

    if ($state.Statuses[1].DisplayStatus  -eq "VM running")
    {
    Write-Output "$vmtoconsider is stated successfully"
    }
    else
    {
    Write-Output "$vmtoconsider is failed to start"
    }



}


